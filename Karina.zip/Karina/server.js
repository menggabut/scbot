let {
    WAConnection: _WAConnection,
    MessageType, 
    Presence,
    Mimetype,
    GroupSettingChange
} = require("@adiwajshing/baileys");
let simple  = require('./plugins/simple.js');
let WAConnection = simple.WAConnection(_WAConnection);
let { color, bgcolor } = require('./lib/color.js');
let { banner, start, success, getGroupAdmins } = require('./lib/functions')
let { ucapanWaktu } = require('./lib/setting')
let qrcode = require("qrcode-terminal");
let fs = require('fs');
let { exec } = require('child_process')
let moment = require('moment-timezone')
let chalk = require('chalk');
let colors = require('colors');
let spin = require('spinnies');
let async = require('async');
let CFonts = require('cfonts');
let path = require('path');
let figlet = require('figlet');
let bal = { "key": {	"fromMe": false, "participant": "0@s.whatsapp.net",	"remoteJid": "0@s.whatsapp.net"	}, "message": { "groupInviteMessage": {	"groupJid": "6288213840883-1616169743@g.us", "inviteCode": "mememteeeekkeke", "groupName": "P", "caption": `Created By Iqbalzz`, "jpegThumbnail": fs.readFileSync('./media/BaseIqbalzz.jpg') } } }
ownerN = "628983583288"
fake = 'Whatsapp-Bot'
spc1 = '         '
spc2 = '\n                           '
spc3 = '                   '
spc4 = '               '
spc5 = '  '
spc6 = '\n             '
spc7 = '            '

require('./Iqbal.js')
nocache('./Iqbal.js', module => console.log(`${module} is now updated!`))

function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);

  //return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)
  return `${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik`
}

function tanggal(){
myMonths = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
			myDays = ['Minggu','Senin','Selasa','Rabu','Kamis','Jum at','Sabtu'];
			var tgl = new Date();
			var day = tgl.getDate()
			bulan = tgl.getMonth()
			var thisDay = tgl.getDay(),
			thisDay = myDays[thisDay];
			var yy = tgl.getYear()
			var year = (yy < 1000) ? yy + 1900 : yy;
			return `${thisDay}, ${day} - ${myMonths[bulan]} - ${year}`
}
function waktu(seconds) {
	seconds = Number(seconds);
	var d = Math.floor(seconds / (3600 * 24));
	var h = Math.floor(seconds % (3600 * 24) / 3600);
	var m = Math.floor(seconds % 3600 / 60);
	var s = Math.floor(seconds % 60);
	var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
	var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
	var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
	var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
	return dDisplay + hDisplay + mDisplay + sDisplay;
}
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jams = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();

switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
            switch(jams){
                case 0: jams = "Tengah Malam🌃"; break;
                case 1: jams = "Tengah Malam🌃"; break;
                case 2: jams = "Tengah Malam🌃"; break;
                case 3: jams = "Tengah Malam🌃"; break;
                case 4: jams = "Sahur🍙"; break;
                case 5: jams = "Subuh🕌"; break;
                case 6: jams = "Pagi🏙"; break;
                case 7: jams = "Pagi🏙"; break;
                case 8: jams = "Pagi🏙"; break;
                case 9: jams = "Pagi🏙"; break;
                case 10: jams = "Pagi🏙"; break;
                case 11: jams = "Siang🌁"; break;
                case 12: jams = "Dzuhur🕌"; break;
                case 13: jams = "Siang🌁"; break;
                case 14: jams = "Siang🌁"; break;
                case 15: jams = "Ashar🕌"; break;
                case 16: jams = "Sore🌇"; break;
                case 17: jams = "Petang🌆"; break;
                case 18: jams = "Buka Puasa👨‍👩‍👧‍👦"; break;
                case 19: jams = "isya🕌"; break;
                case 20: jams = "Malam🌆"; break;
                case 21: jams = "Malam🌆"; break;
                case 22: jams = "Oyasumi Nassai🌌"; break;
                case 23: jams = "Tengah Malam🌃"; break;
            }
var tampilTanggal = hari + " "+ tanggal + " " + bulan + " " + tahun;
var tampilWaktu = menit + ":" + detik;
var tampilHari = "" + jams;

const starts = async (iqbl = new WAConnection()) => {
    iqbl.logger.level = 'warn'
    console.log(color(figlet.textSync(`${spc1}Iqbalzz`, {
	font: 'Standard',
	horizontalLayout: 'default',
	vertivalLayout: 'default',
	width: 80,
	whitespaceBreak: false
	}), 'cyan'))
    iqbl.version = [2, 2123, 8]
    iqbl.browserDescription = [ 'ItsMeIqbalzz','Safari', 'FAIII' ]
console.log(color(`${spc6}[ • BOT Creator By Iqbalzz • ]` ,'cyan'))
console.log(color(`${spc5}< ================================================== >`, 'cyan'))
console.log(color(`${spc7}[•]`, 'aqua'), color(`Nama        : ${fake}`, 'white'))
console.log(color(`${spc7}[•]`, 'aqua'), color(`Bot Version : 2.2.2`, 'white'))
console.log(color(`${spc7}[•]`, 'aqua'), color(`Status      : Online!`, 'white'))
console.log(color(`${spc7}[•]`, 'aqua'), color(`Owner       : ${ownerN}`, 'white'))
console.log(color(`${spc5}< ================================================== >`, 'cyan'))
    iqbl.on('qr', () => {
    console.log(color('[','white'), color('!','red'), color(']','white'), color('Scan QR Diatas Untuk Menyambungkan Bot WhatsApp!\n1. Klik titik tiga di pojok kanan atas\n2. Ketuk WhatsApp Web\n3. Scan QR ini \n\nQR Expired dalam 20 detik'))
    })
    
    //Session
    fs.existsSync('./session.json') && iqbl.loadAuthInfo('./session.json')
    iqbl.on('connecting', () => {
        //Ubah Aja Sesuai Kata Kata Kalian
        iqbl.logger.warn('Selamat Datang Kak!!') 	
        iqbl.logger.warn('Jangan Lupa Sholat🤗')
        iqbl.logger.warn('Gunakan Bot Ini Sebaik Mungkin')
        iqbl.logger.warn('Terima Kasih Atas Menggunakan Bot Dengan Baik')
        console.log(color('[ SYSTEM ]', 'orange'), color('Menyambungkan... ','deeppink'));
    })
 
//Plugins
let pluginFolder = path.join(__dirname, 'plugins')
let pluginFilter = filename => /\.js$/.test(filename)
global.plugins = {}
for (let filename of fs.readdirSync(pluginFolder).filter(pluginFilter)) {
  try {
    global.plugins[filename] = require(path.join(pluginFolder, filename))
  } catch (e) {
    conn.logger.error(e)
    delete global.plugins[filename]
  }
}
console.log(Object.keys(global.plugins))
global.reload = (_event, filename) => {
  if (pluginFilter(filename)) {
    let dir = path.join(pluginFolder, filename)
    if (dir in require.cache) {
      delete require.cache[dir]
      if (fs.existsSync(dir)) conn.logger.info(`re - require plugin '${filename}'`)
      else {
        conn.logger.warn(`deleted plugin '${filename}'`)
        return delete global.plugins[filename]
      }
    } else conn.logger.info(`requiring new plugin '${filename}'`)
    let err = syntaxerror(fs.readFileSync(dir), filename)
    if (err) conn.logger.error(`syntax error while loading '${filename}'\n${err}`)
    else try {
      global.plugins[filename] = require(dir)
    } catch (e) {
      conn.logger.error(e)
    } finally {
      global.plugins = Object.fromEntries(Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b)))
    }
  }
}
Object.freeze(global.reload)
fs.watch(path.join(__dirname, 'plugins'), global.reload)

//Open
    iqbl.on('open', () => {
    console.log(colors.white.underline(color('\nTanggal •','silver'), color(tampilTanggal)));
    console.log(colors.white.underline(color('Waktu •','silver'), color(tampilWaktu)));
    console.log(colors.white.underline(color('Sekarang •','silver'), color(tampilHari)));
	console.log(colors.yellow.bold('\nCreated By: @Iqbalzz'));
	console.log(colors.yellow.bold('whatsapp : +62813-1599-5628'));
	console.log(colors.red.underline('Saya Bukan Mastah'));
    console.log(colors.bold.white(colors.strikethrough('Hai Perkenalkan Nama Saya Iqbalzz Saya Membuat Bot Hanya Gabut Aja Dan Saya Tidak Jago Amat Di Dunia Bot Dan Script Ini Di Susun Oleh @Iqbalzz Dan Di Bantu Sama Temen-Temen Aku, Script Ini Jangan Di Jual Belikan')));
    setTimeout( () => {
    console.log(color('[ SYSTEM ]', 'orange'), color('Tersambung... ','greenyellow'));	    	    
    }, 1000)    	
    })
    
	await iqbl.connect({timeoutMs: 30*1000})
	start('2',colors.bold.blue('\nMenunggu Pesan Baru...\n   『々Lord』ᴹᴿIqbalzzツ'));
        fs.writeFileSync('./session.json', JSON.stringify(iqbl.base64EncodedAuthInfo(), null, '\t'))
      
      iqbl.on("group-participants-update", async (anu) => {
    try {
      groupMet = await iqbl.groupMetadata(anu.jid);
      groupMembers = groupMet.participants;
      groupAdmins = getGroupAdmins(groupMembers);
      mem = anu.participants[0];

      console.log(anu);
      try {
        pp_user = await iqbl.getProfilePicture(mem);
      } catch (e) {
        pp_user =
          "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60";
      }
      try {
        pp_grup = await iqbl.getProfilePicture(anu.jid);
      } catch (e) {
        pp_grup =
          "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60";
      }
      if (anu.action == "add" && mem.includes(iqbl.user.jid)) {
        iqbl.sendMessage(anu.jid, "Assalamualaikum😊", "conversation");
      }
                hehe = await getBuffer(pp_user)
            if (anu.action == 'add' && !mem.includes(iqbl.user.jid)) {
                const mdata = await iqbl.groupMetadata(anu.jid) 
                const num = anu.participants[0]
                const bosco1 = await iqbl.prepareMessage("0@s.whatsapp.net", hehe, MessageType.location,{ thumbnail: hehe})
			    const bosco2 = bosco1.message["ephemeralMessage"] ? bosco1.message.ephemeralMessage : bosco1
                teks = `Hi @${num.split('@')[0]}\n\nNama : \nUmur :\nGender : \nAsal :\n\nSemoga Betah`;
                welcomeBut = [{buttonId:`Welcome🗿`,buttonText:{displayText:'Welcome🗿'},type:1}]
                welcomeButt = { contentText: `${teks}`, footerText: `Created By Iqbalzz`, buttons: welcomeBut, headerType: 6, locationMessage: bosco2.message.locationMessage}
                iqbl.sendMessage(mdata.id, welcomeButt, MessageType.buttonsMessage, { caption: 'hehe', "contextInfo": { "mentionedJid" : [num], },})
                 }
           if (anu.action == 'remove' && !mem.includes(iqbl.user.jid)) {
                const mdata = await iqbl.groupMetadata(anu.jid)
                const num = anu.participants[0]
                const bosco3 = await iqbl.prepareMessage("0@s.whatsapp.net", hehe, MessageType.location,{ thumbnail: hehe})
			    const bosco4 = bosco3.message["ephemeralMessage"] ? bosco3.message.ephemeralMessage : bosco3
                out = `Sayonara👋\n@${num.split('@')[0]}`
                goodbyeBut = [{buttonId:`h`,buttonText:{displayText:'Sayonara🗿'},type:1}]
                goodbyeButt = { contentText: `${out}`, footerText: `Created By Iqbalzz`, buttons: goodbyeBut, headerType: 6, locationMessage: bosco3.message.locationMessage}
                iqbl.sendMessage(mdata.id, goodbyeButt, MessageType.buttonsMessage, { caption: 'hehe', "contextInfo": { "mentionedJid" : [num], },})
            }
      if (anu.action == "promote") {
      	const bosco5 = await iqbl.prepareMessage("0@s.whatsapp.net", hehe, MessageType.location,{ thumbnail: hehe})
		  const bosco6 = bosco5.message["ephemeralMessage"] ? bosco5.message.ephemeralMessage : bosco5
          const mdata = await iqbl.groupMetadata(anu.jid)
          const num = anu.participants[0]
          promote = `Selamat @${num.split('@')[0]} Sekarang Kamu Admin`
          promotebut = [{buttonId:`h`,buttonText:{displayText:'Yey🗿'},type:1}]
          promoteButt = { contentText: `${promote}`, footerText: `Created By Iqbalzz`, buttons: promotebut, headerType: 6, locationMessage: bosco6.message.locationMessage}
          iqbl.sendMessage(mdata.id, promoteButt, MessageType.buttonsMessage, { caption: 'hehe', "contextInfo": { "mentionedJid" : [num], },})
            }

      if (anu.action == "demote") {
          const bosco7 = await iqbl.prepareMessage("0@s.whatsapp.net", hehe, MessageType.location,{ thumbnail: hehe})
		  const bosco8 = bosco7.message["ephemeralMessage"] ? bosco7.message.ephemeralMessage : bosco7
          const mdata = await iqbl.groupMetadata(anu.jid)
          const num = anu.participants[0]
          demote = `Yah @${num.split('@')[0]} Di Demote😔`
          demotebut = [{buttonId:`h`,buttonText:{displayText:'Yah😔'},type:1}]
          demoteButt = { contentText: `${demote}`, footerText: `Created By Iqbalzz`, buttons: demotebut, headerType: 6, locationMessage: bosco8.message.locationMessage}
          iqbl.sendMessage(mdata.id, demoteButt, MessageType.buttonsMessage, { caption: 'hehe', "contextInfo": { "mentionedJid" : [num], },})
            }
    } catch (e) {
      console.log("Error : %s", color(e, "red"));
    }
  });
      
iqbl.on('group-update', async (anu) => {
fgcl = { key: {fromMe: false,participant: "0@s.whatiqbl.net", remoteJid: "0@s.whatsapp.net"},message: {"groupInviteMessage": {"groupJid": "6288213840883-1616169743iqbls","inviteCode": "mememteeeekkeke","groupName": "Iqbalzz", "caption": `Iqbalzz`, 'jpegThumbnail': fs.readFileSync('./media/BaseIqbalzz.jpg')}}}
  metdata = await iqbl.groupMetadata(anu.jid)
    if(anu.announce == 'false'){
    teks = `- [ Group Opened ] -\n\n_Group telah dibuka oleh admin_\n_Sekarang semua member bisa mengirim pesan_`
    iqbl.sendMessage(metdata.id, teks, MessageType.text, {quoted: bal, sendEphemeral: true})
    console.log(`- [ Group Opened ] - In ${metdata.subject}`)
  }
  else if(anu.announce == 'true'){
    teks = `- [ Group Closed ] -\n\n_Group telah ditutup oleh admin_\n_Sekarang hanya admin yang dapat mengirim pesan_`
    iqbl.sendMessage(metdata.id, teks, MessageType.text, {quoted: bal, sendEphemeral: true})
    console.log(`- [ Group Closed ] - In ${metdata.subject}`)
  }
  else if(!anu.desc == ''){
    tag = anu.descOwner.split('@')[0] + '@s.whatsapp.net'
    teks = `- [ Group Description Change ] -\n\nDeskripsi Group telah diubah oleh Admin @${anu.descOwner.split('@')[0]}\n• Deskripsi Baru : ${anu.desc}`
    iqbl.sendMessage(metdata.id, teks, MessageType.text, {contextInfo: {"mentionedJid": [tag]}, quoted: bal, sendEphemeral: true})
    console.log(`- [ Group Description Change ] - In ${metdata.subject}`)
  }
  else if(anu.restrict == 'false'){
    teks = `- [ Group Setting Change ] -\n\nEdit Group info telah dibuka untuk member\nSekarang semua member dapat mengedit info Group Ini`
    iqbl.sendMessage(metdata.id, teks, MessageType.text, {quoted: bal, sendEphemeral: true})
    console.log(`- [ Group Setting Change ] - In ${metdata.subject}`)
  }
  else if(anu.restrict == 'true'){
    teks = `- [ Group Setting Change ] -\n\nEdit Group info telah ditutup untuk member\nSekarang hanya admin group yang dapat mengedit info Group Ini`
    iqbl.sendMessage(metdata.id, teks, MessageType.text, {quoted: bal, sendEphemeral: true})
    console.log(`- [ Group Setting Change ] - In ${metdata.subject}`)
  }
})

//Anti Delete
antidel = false
iqbl.on('message-delete', async (m) => {
if (m.key.remoteJid == 'status@broadcast') return
if (!m.key.fromMe && m.key.fromMe) return
if (antidel === false) return
m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message
const jam = moment.tz('Asia/Jakarta').format('HH:mm:ss')
let d = new Date
let locale = 'id'
let gmt = new Date(0).getTime() - new Date('1 Januari 2021').getTime()
let weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let calender = d.toLocaleDateString(locale, {
day: 'numeric',
month: 'long',
year: 'numeric'
})
const type = Object.keys(m.message)[0]
iqbl.sendMessage(m.key.remoteJid, `\`\`\`「 Anti Delete 」\`\`\`
•> Nama : @${m.participant.split("@")[0]}
•> Waktu : ${jam} ${week} ${calender}
•> Type : ${type}`, MessageType.text, {quoted: m.message, contextInfo: {"mentionedJid": [m.participant], "externalAdReply": {"title": `Hayolo Ngapus Apaan?`, "body": `${ucapanWaktu}`, mediaType: 2, "thumbnailUrl": "https://telegra.ph/file/6b0259fd741e108910fbe.jpg","previewType": "VIDEO","mediaUrl": `https://fb.watch/8f0gXPj5p0/`}}})

iqbl.copyNForward(m.key.remoteJid, m.message)
})

//Baterai
baterai = `belum detect`
charging = `unknown`
iqbl.on('CB:action,,battery', json => {
		global.batteryLevelStr = json[2][0][1].value
	   global.batterylevel = parseInt(batteryLevelStr)
		baterai = batterylevel
        if (json[2][0][1].live == 'true') charging = true
       if (json[2][0][1].live == 'false') charging = false
        console.log(json[2][0][1])
		console.log('Baterai : ' + batterylevel+'%')
	})
	global.batrei = global.batrei ? global.batrei : []
		iqbl.on('CB:action,,battery', json => {
		const batteryLevelStr = json[2][0][1].value
		const batterylevel = parseInt(batteryLevelStr)
		global.batrei.push(batterylevel)
		}) 
		
    iqbl.on('CB:Conn,pushname', json => {
    const pushname = json[1].pushname
    iqbl.user.name = pushname // update on client too
    console.log ("Name updated: " + pushname)
})

iqbl.on('chat-update', async (message) => {
        require('./Iqbal.js')(iqbl, message)
    })
    }

/**
 * Uncache if there is file change
 * @param {string} module Module name or path
 * @param {function} cb <optional> 
 */
function nocache(module, cb = () => { }) {
    console.log('Module', `'${module}'`, 'is now being watched for changes')
    fs.watchFile(require.resolve(module), async () => {
        await uncache(require.resolve(module))
        cb(module)
    })
}

/**
 * Uncache a module
 * @param {string} module Module name or path
 */
function uncache(module = '.') {
    return new Promise((resolve, reject) => {
        try {
            delete require.cache[require.resolve(module)]
            resolve()
        } catch (e) {
            reject(e)
        }
    })
}

starts()
